<?php
require_once '../lib/connection.php';

$id = $_GET['id'] ?? '';

if($id == '')
{
    echo 0;
    exit;
}

$sql = "SELECT Status FROM barang WHERE ID='$id'";
$res = mysqli_query($conn, $sql);

if(!$res || mysqli_num_rows($res) == 0)
{
    echo 0;
    exit;
}

$row = mysqli_fetch_row($res);
$stts = $row[0] ?? 0;

$new_stts = ($stts == 1) ? 0 : 1;

$sql = "UPDATE barang SET Status='$new_stts' WHERE ID='$id'";
mysqli_query($conn, $sql);

echo $new_stts;
?>