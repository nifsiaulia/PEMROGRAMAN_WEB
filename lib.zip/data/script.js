function ToggleStatus(ID) {
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("GET", "./ajax/set_status.php?id=" + ID, true);

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var stts = xmlhttp.responseText;

            var obj = document.getElementById(ID);

            if (obj) {
                obj.style.opacity = (stts == 1) ? "1" : "0.5";
            }
        }
    };

    xmlhttp.send();
}