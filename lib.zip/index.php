<?php
ob_start();
session_start();

require_once './lib/library.php';
require_once './lib/barang.php';
require_once './lib/tipe.php';
require_once './lib/pelanggan.php';
require_once './lib/transaksi.php';

include './lib/connection.php';
GenerateTable($conn);

echo '<title>Indoapril</title>';
echo '<style>'.file_get_contents('./data/style.css').'</style>';
echo '<script>'.file_get_contents('./data/script.js').'</script>';

$menu = GET('menu', 'home');

/* ================= NAVBAR ================= */
echo '
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h2 style="color:#2c7da0;">Indoapril</h2>

    <div class="nav-menu">
        <a href="?menu=barang" class="'.($menu=='barang'?'active':'').'">Barang</a>
        <a href="?menu=tipe" class="'.($menu=='tipe'?'active':'').'">Tipe</a>
        <a href="?menu=pelanggan" class="'.($menu=='pelanggan'?'active':'').'">Pelanggan</a>
        <a href="?menu=transaksi" class="'.($menu=='transaksi'?'active':'').'">Transaksi</a>
    </div>
</div>
';

/* ================= CONTENT BOX (HANYA 1 FIELDSET) ================= */
echo '<fieldset>';

if($menu == 'home')
{
    echo '
    <div class="home-box">
        <h1>WELCOME TO INDOAPRIL</h1>
        <p>Sistem Manajemen Barang Sederhana</p>
    </div>';
}
elseif($menu == 'barang')
{
    DataBarang();
}
elseif($menu == 'tipe')
{
    DataTipe();
}
elseif($menu == 'pelanggan')
{
    DataPelanggan();
}
elseif($menu == 'transaksi')
{
    DataTransaksi();
}

echo '</fieldset>';
?>
